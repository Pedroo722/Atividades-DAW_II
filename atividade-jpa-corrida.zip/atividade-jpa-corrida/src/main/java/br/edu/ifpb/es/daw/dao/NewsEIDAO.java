package br.edu.ifpb.es.daw.dao;

import br.edu.ifpb.es.daw.entities.embeddedid.NewsEI;
import br.edu.ifpb.es.daw.entities.embeddedid.NewsIdEI;

public interface NewsEIDAO extends DAO<NewsEI, NewsIdEI> {

}
