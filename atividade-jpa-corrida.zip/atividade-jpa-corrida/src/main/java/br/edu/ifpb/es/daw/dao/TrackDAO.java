package br.edu.ifpb.es.daw.dao;

import br.edu.ifpb.es.daw.entities.Track;

public interface TrackDAO extends DAO<Track, Long> {

}
