package br.edu.ifpb.es.daw.dao;

import br.edu.ifpb.es.daw.entities.idclass.NewsIC;
import br.edu.ifpb.es.daw.entities.idclass.NewsIdIC;

public interface NewsICDAO extends DAO<NewsIC, NewsIdIC> {

}
