package br.edu.ifpb.es.daw.entities;

public class Corrida {
    
}
